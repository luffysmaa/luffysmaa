## <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="29px"> I'm BAGIRA
<p align="center">
<p align='center'><a href="https://instagram.com/bagiraelazef"><img height="200" src="https://d.top4top.io/s_2021hqnie0.jpeg"></a>&nbsp;&nbsp;</p>
</p>
<br>



<p align="center">
<a href="#"><img title="BAGIRA ID" src="https://d.top4top.io/s_2021hqnie0.jpeg"></a>
</p>
<p align="center">
<a href="https://d.top4top.io/s_2021hqnie0.jpeg"><img title="Author" src="https://d.top4top.io/s_2021hqnie0.jpeg"></a>
</p>
<p align="center">
<a href="https://github.com/fox-alaam/BAGIRABOT2/followers"><img title="Followers" src="https://d.top4top.io/s_2021hqnie0.jpeg"></a>
<a href="https://github.com/fox-alaam/BAGIRABOT2/stargazers/"><img title="Stars" src="https://d.top4top.io/s_2021hqnie0.jpeg"></a>
<a href="https://github.com/fox-alaam/BAGIRABOT2/network/members"><img title="Forks" src="https://d.top4top.io/s_2021hqnie0.jpeg"></a>
<a href="https://github.com/fox-alaam/BAGIRABOT2/watchers"><img title="Watching" src="https://d.top4top.io/s_2021hqnie0.jpeg"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fgjbae1212%2Fbagirabot&count_bg=%2379C83D&title_bg=%23555555&icon=lmms.svg&icon_color=%23E8E8E8&title=bagirabot&edge_flat=true"/></a>
</p>
<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Developer.gif" alt="Mario Game" width="600" />
<div align="center">
<details>
 
</details>

### 𝗧𝗵𝗮𝗻𝗸𝘀 𝗙𝗼𝗿 𝐁𝐀𝐆𝐈𝐑𝐀 𝗜𝗗

### WARNING
MAU RE-UPLOAD SCRIPT? KASIH NAMA/LINK CHANEL SAYA.... DILARANG UBAH INFO!!!

## NOTE:> 
SCRIPTNYA JANGAN DI JUAL/BELI KAN.. SCRIPT INI 100% GRATIS BUAT KALIAN PENGGUNA TERMUX
</div>

### ALAT DAN BAHAN <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Mario_Hello_Big.gif" width="29px">
Siapin alat dan bahannya.
```bash
> niat
> 2 handphone (1 buat jalanin sc, 1 buat scan kode qr kak)
> jaringan internet kenceng,kuota+
> penyimpanan yang memadai
> aplikasi whatsapp
> aplikasi termux
> kopi+rokok ;v
```
## Edit disini
Buka nih [`Ramlan.json`](https://github.com/fox-alaam/BAGIRABOT2/edit/main/settings/Ramlan.json). Apikey Free Tinggal regist [`ZEKS API`](https://api.lolhuman.xyz/login).
```json
{
    "botName": "BAGIRA BOT",
    "ownerName": "BAGIRA BOTZ",
    "ownerNumbers": "201060647991",
    "ZeksApi": "apivinz",
    "botPrefix": "!",
    "GrupLimitz": "0",
    "autor": "BAGIRA ELAZEF",
    "peknem": "BAGIRA-BOT",
    "CeerTod": "*BAGIRA BOTZ VERIFIED*"
}

```
### CARA INSTALLNYA  <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/hmm.gif" width="29px">
```bash
> kalo lu belum punya apk termux, download di playstore
> masuk ke apk termux lalu ketik dibawah ini!
> termux-setup-storage [ Lalu Ijinkan ]
> apt-get update -y
> apt-get upgrade -y
> pkg install git -y
> pkg install bash -y
> pkg install mc -y
> git clone https://github.com/fox-alaam/BAGIRABOT2
> cd babybot
> bash install.sh
> npm start
> SCAN DAH BRO MHEHE EZ KAN:V
```


Ket: Script ini gratis ye Jangan dijual_-

## DONASI <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/coin.gif" width="29px">
* [`Donasi BAGIRA ID`](https://saweria.co/bagiraelazef)


## SOSIAL MEDIA ADMIN <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/powerup.gif" width="29px">

* [`Youtube Admin`](https://youtube.com/c/IBAGIRAELAZEFI)
* [`Instagram Admin`](https://instagram.com/bagiraelazef)
* [`WhatsApp Admin `](https://wa.me/+201060647991)
* [`Group WhatsApp `](https://chat.whatsapp.com/HcXylJBRpkF5Xx9GJpcmbP)
## THANKS TO <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Handshake.gif" width="60px">

* [`ALLAH SWT`]
<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Mario_Gameplay.gif" alt="Mario Game" width="600" />

